#ifndef _tokenizeString_h
#define _tokenizeString_h
#include <stdlib.h>

char **tokenizeString( char *str, int *retTokenCount );

#endif
